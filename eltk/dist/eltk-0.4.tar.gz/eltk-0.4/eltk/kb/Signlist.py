# -*- coding: UTF-8 -*-
#
# e-Linguistics Toolkit: Signlist 
#
# Copyright (C) 2008 ELTK Project
# Author: Scott Farrar <farrar@u.washington.edu>
# URL: <http://purl.org/linguistics/eltk>
# For license information, see LICENSE.TXT
"""
Signlist module
"""

import eltk
from eltk.namespace import GOLDNS
from eltk.kb.Meta import *
from eltk.utils.functions import getLocalName
from eltk.kb.KBComponent import KBComponent





class Signlist(KBComponent):
    """
    Not sure whether this is needed or not.
    """
    pass
if __name__=='__main__':

    pass
