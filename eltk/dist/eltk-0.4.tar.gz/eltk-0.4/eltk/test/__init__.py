# -*- coding: UTF-8 -*-
#
# e-Linguistics Toolkit: unittest 
#
# Copyright (C) 2008 ELTK Project
# Author: Scott Farrar <farrar@u.washington.edu>
# URL: <http://e-linguistics.org>
# For license information, see LICENSE.TXT

